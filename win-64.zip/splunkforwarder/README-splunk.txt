
Splunk 8.2.4
December, 2021
Splunk Enterprise is the data collection, indexing, and visualization engine for operational intelligence.

Splunk online documentation is located at:
* http://docs.splunk.com/Documentation/Splunk

For installation and set-up instructions, refer to the Installation Manual:
* http://docs.splunk.com/Documentation/Splunk/latest/Installation

For release notes, refer to the Known issues in the Release Notes manual:
* http://docs.splunk.com/Documentation/Splunk/latest/ReleaseNotes/Knownissues
